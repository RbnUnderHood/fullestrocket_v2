# CSS Cleanup Report (Doc-only)

No visual changes were made. Added file headers to CSS files and generated docs.

## Duplicate selectors across files (consider consolidation later)
- `#btnCalc` appears in: css/components/results.css, styles.css
- `#results .kv` appears in: css/components/results.css, styles.css
- `#results .metric` appears in: css/components/help.css, css/components/metric-bands.css
- `.actions` appears in: css/components/density.css, styles.css
- `.grid` appears in: css/components/forms.css, styles.css
- `.issues` appears in: css/components/density.css, styles.css
- `.post-actions` appears in: css/components/results.css, styles.css
- `.row` appears in: css/components/forms.css, styles.css
- `.site-footer` appears in: css/components/layout.css, styles.css
- `.slogan` appears in: css/components/density.css, css/components/header.css
- `0` appears in: css/components/help.css, css/components/metric-bands.css, css/components/results-clean.css, css/components/results-fun.css, styles.css
- `0.06)` appears in: css/components/results-clean.css, css/components/results-fun.css
- `23` appears in: css/components/results-clean.css, css/components/results-fun.css
- `42` appears in: css/components/results-clean.css, css/components/results-fun.css
- `:root` appears in: css/components/density.css, css/theme.css, styles.css
- `body` appears in: css/components/density.css, styles.css
- `flex-direction: column;
  }
  .post-actions .btn.block` appears in: css/components/results.css, styles.css
- `font-weight: 600;
}


@media (max-width: 600px)` appears in: css/components/results.css, styles.css
- `grid-template-columns: 1fr;
  }
  #results .kv .v` appears in: css/components/results.css, styles.css
- `textarea` appears in: css/components/density.css, styles.css

## Files touched (headers added if missing)

- styles.css: header inserted
- css/theme.css: header inserted
- css/components/ads.css: header inserted
- css/components/alt-feed.css: header inserted
- css/components/density.css: header inserted
- css/components/feed-prices.css: header inserted
- css/components/forms.css: header inserted
- css/components/header.css: header inserted
- css/components/help.css: header inserted
- css/components/layout.css: header inserted
- css/components/metric-bands.css: header inserted
- css/components/results-clean.css: header inserted
- css/components/results-fun.css: header inserted
- css/components/results.css: header inserted
- css/components/units.css: header inserted

## TODO (safe next steps)
- Consolidate `.post-actions` into `css/components/density.css` and remove from `results.css`.
- Move global spacing tokens (`--space-*`) into `css/theme.css`; keep component-specific overrides local.
- Consider archiving `metric-bands.css` and `results-fun.css` if not used.
