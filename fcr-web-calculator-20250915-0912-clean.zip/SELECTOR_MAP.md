# Selector Map (owner files)

- `#334155);
}
#moreMetrics .metric .metric__label` → css/components/results-clean.css
- `#334155); 
}
#metricsGrid .metric .metric__label` → css/components/results-clean.css
- `#556b2f);
}
#metricsGrid.metric-grid-scope .metric.band-average` → css/components/results-fun.css
- `#6a6a6a);
}
#results .kv .v` → css/components/results.css
- `#87ceeb);
}
#metricsGrid.metric-grid-scope .metric.band-good` → css/components/results-fun.css
- `#btnCalc` → css/components/results.css, styles.css
- `#daa520);
}
#metricsGrid.metric-grid-scope .metric.band-poor` → css/components/results-fun.css
- `#e2e8f0) 12%` → css/components/results-fun.css
- `#e2e8f0);
  border-radius: 14px;
  box-shadow: var(
    --tile-shadow` → css/components/results-fun.css
- `#e2e8f0);
  border-radius: 14px;
  box-shadow: var(--tile-shadow);
  transform: rotate(-0.8deg);
  transition: transform 0.18s ease` → css/components/results-fun.css
- `#e2e8f0);
  border-radius: 14px;
  padding: 12px 12px 10px;
  box-shadow: 0 1px 0 rgba(0` → css/components/results-clean.css
- `#e5e7eb);
  border-left: 6px solid var(--band-color` → css/components/results-fun.css
- `#fff
  );
}

.fun-grid .metric__value` → css/components/results-fun.css
- `#fff)` → css/components/results-fun.css
- `#fff);
  border: 1px solid var(--tile-border` → css/components/results-fun.css
- `#ffffff
  );
}


#metricsGrid.metric-grid-scope .metric .metric__value` → css/components/results-fun.css
- `#ffffff)` → css/components/results-fun.css
- `#metricsGrid` → css/components/results-clean.css
- `#metricsGrid.metric-grid-scope .metric` → css/components/results-fun.css
- `#metricsGrid.metric-grid-scope .metric:hover` → css/components/results-fun.css
- `#results *` → styles.css
- `#results .grid` → css/components/results-clean.css
- `#results .kv` → css/components/results.css, styles.css
- `#results .kv .row` → css/components/results.css
- `#results .metric` → css/components/help.css, css/components/metric-bands.css
- `*::after` → css/components/forms.css
- `*::before` → css/components/forms.css
- `--alt-gap: 12px;
  --alt-min: 240px;
}

.alt-feed .alt-box` → css/components/alt-feed.css
- `--band-color: #0fd658;
} 
#metricsGrid .metric.band-average` → css/components/results-clean.css
- `--band-color: #3b8144;
} 
#metricsGrid .metric.band-poor` → css/components/results-clean.css
- `--band-color: #87ceeb;
} 
#metricsGrid .metric.band-good` → css/components/results-clean.css
- `--band-color: #c41e3a;
} 


#metricsGrid .metric` → css/components/results-clean.css
- `--band-color: var(--field-green` → css/components/results-fun.css
- `--band-color: var(--field-green);
}
.fun-grid .metric.band-average` → css/components/results-fun.css
- `--band-color: var(--hay-gold` → css/components/results-fun.css
- `--band-color: var(--hay-gold);
}
.fun-grid .metric.band-poor` → css/components/results-fun.css
- `--band-color: var(--rooster-red);
}


.results-sub` → css/components/results-fun.css
- `--band-color: var(--sky-blue` → css/components/results-fun.css
- `--band-color: var(--sky-blue);
}
.fun-grid .metric.band-good` → css/components/results-fun.css
- `--bg: #f7fbf7;
  --card: #fff;
  --ink: #223;
  --muted: #666;
  --brand: #2e7d32;
  --brand-ink: #fff;
  --border: #e6ece6;
  --warn: #b45309;
  --ok: #0b7a0b;
}

*` → styles.css
- `--font-base: 14px; 
  --font-label: 13px;
  --font-metric: 18px; 
  --space-1: 6px;
  --space-2: 10px;
  --space-3: 12px;
  --space-4: 16px;
}

html` → css/components/density.css
- `--gap: 12px;
  --min: 240px;
}
.feed-prices .alt-box` → css/components/feed-prices.css
- `--tile-bg: #ffffff;
  --tile-border: #e5e7eb; 
  border-left: 4px solid var(--tile-border);
  border-radius: 12px;
  padding: 10px 12px;
  background: var(--tile-bg);
  box-shadow: 0 0 0 1px rgba(0` → css/components/metric-bands.css
- `.actions` → css/components/density.css, styles.css
- `.ad` → styles.css
- `.ad.ad--mobile` → css/components/ads.css
- `.alt-feed` → css/components/alt-feed.css
- `.alt-feed .row .field` → css/components/alt-feed.css
- `.alt-feed input[type="text"]` → css/components/alt-feed.css
- `.badge` → css/components/header.css
- `.card-title-bar` → css/components/units.css
- `.container` → css/components/layout.css
- `.expando` → styles.css
- `.feed-prices` → css/components/feed-prices.css
- `.feed-prices .row .field` → css/components/feed-prices.css
- `.field` → css/components/forms.css
- `.field select` → css/components/forms.css
- `.field textarea` → css/components/forms.css
- `.fun-grid .metric` → css/components/results-fun.css
- `.fun-grid .metric:hover` → css/components/results-fun.css
- `.grid` → css/components/forms.css, styles.css
- `.info` → css/components/help.css
- `.issues` → css/components/density.css, styles.css
- `.kv` → css/components/forms.css
- `.metric__label` → css/components/density.css
- `.post-actions` → css/components/results.css, styles.css
- `.row` → css/components/forms.css, styles.css
- `.row.row--compact` → css/components/forms.css
- `.site-footer` → css/components/layout.css, styles.css
- `.slogan` → css/components/density.css, css/components/header.css
- `.unit-note` → css/components/density.css
- `.units-switch .seg span` → css/components/units.css
- `.wrap` → css/components/layout.css
- `0` → css/components/help.css, css/components/metric-bands.css, css/components/results-clean.css, css/components/results-fun.css, styles.css
- `0 10px 24px rgba(15` → css/components/results-fun.css
- `0 1px 0 rgba(0` → css/components/results-fun.css
- `0 6px 16px rgba(15` → css/components/results-fun.css
- `0 8px 18px rgba(15` → css/components/results-clean.css
- `0.03);
}
.card-title` → styles.css
- `0.04) inset; 
  transition: background-color 0.2s ease` → css/components/metric-bands.css
- `0.06)` → css/components/results-clean.css, css/components/results-fun.css
- `0.06)
  );
  transform: rotate(-0.8deg);
  transition: transform 0.18s ease` → css/components/results-fun.css
- `0.08);
}


#metricsGrid .metric .metric__value` → css/components/results-clean.css
- `0.08);
}
#moreMetrics .metric .metric__value` → css/components/results-clean.css
- `0.09);
  }
}


@media (prefers-reduced-motion: reduce)` → css/components/results-fun.css
- `0.12);
  border-left-color: #0fd658;
}
#results .metric.band-avg` → css/components/metric-bands.css
- `0.12);
  border-left-color: #3b8144;
}
#results .metric.band-watch` → css/components/metric-bands.css
- `0.12);
  border-left-color: #b45309;
}
#results .metric.band-poor` → css/components/metric-bands.css
- `0.15);
}
#helpPopover.hidden` → css/components/help.css
- `129` → css/components/metric-bands.css
- `12px);
}


.field input` → css/components/forms.css
- `1fr));
  gap: 12px;
  margin-top: 6px;
}
#moreMetrics .metric` → css/components/results-clean.css
- `1fr));
  gap: 12px;
}


#metricsGrid .metric` → css/components/results-clean.css
- `1fr));
  gap: var(--space-3` → css/components/forms.css
- `1fr);
  gap: 10px;
}
@media (max-width: 720px)` → styles.css
- `1fr);
  }
}

.metric` → styles.css
- `1fr); 
}
.post-actions .btn` → css/components/density.css
- `214` → css/components/metric-bands.css
- `23` → css/components/results-clean.css, css/components/results-fun.css
- `42` → css/components/results-clean.css, css/components/results-fun.css
- `68` → css/components/metric-bands.css
- `83` → css/components/metric-bands.css
- `88` → css/components/metric-bands.css
- `9` → css/components/metric-bands.css
- `:root` → css/components/density.css, css/theme.css, styles.css
- `Arial` → styles.css
- `align-self: center;
} 

@media (max-width: 720px)` → styles.css
- `align-self: start;
  align-items: center;
} 
.actions .btn` → styles.css
- `background-color 0.18s ease;

  
  background-image: linear-gradient(
    to bottom right` → css/components/results-fun.css
- `background-color 0.18s ease;
  
  background-image: linear-gradient(
    to bottom right` → css/components/results-fun.css
- `background: #eef2ff;
  border-radius: 9999px;
  padding: 6px 10px;
  color: #334155;
  font-weight: 700;
}
@media (max-width: 360px)` → css/components/units.css
- `background: #f7faf8; 
}


#results .metric.band-good .metric__value` → css/components/metric-bands.css
- `background: #fff8e6;
  border-left: 4px solid #f0a000;
  padding: 10px 12px;
  border-radius: 8px;
  color: #4a3510;
  margin: 8px 0 6px;
}
.unit-note` → styles.css
- `background: rgba(15` → css/components/metric-bands.css
- `background: rgba(180` → css/components/metric-bands.css
- `background: rgba(59` → css/components/metric-bands.css
- `background: transparent;
  border: none;
  color: #2563eb;
  padding: 6px 0;
  font-size: 13px;
  text-decoration: underline;
  cursor: pointer;
}
.btn.linklike.small:hover` → css/components/results-clean.css
- `background: var(--brand);
  color: var(--brand-ink);
  border-color: var(--brand);
}
.btn:active` → styles.css
- `background: var(--card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 16px;
  margin: 16px 0;
  box-shadow: 0 1px 10px rgba(0` → styles.css
- `body` → css/components/density.css, styles.css
- `body *` → styles.css
- `border-color 0.2s ease` → css/components/metric-bands.css
- `border-top: 1px solid var(--border);
  border-bottom: 0;
}

.unit-toggle label` → styles.css
- `border: 1px solid var(--border);
  background: #fff;
  padding: 10px 14px;
  border-radius: 8px;
  cursor: pointer;
}
.btn.primary` → styles.css
- `border: 1px solid var(--border);
  border-left: 4px solid var(--brand);
  background: #f8fdf8;
  padding: 10px;
  border-radius: 8px;
  text-align: center;
}
.metric__value` → styles.css
- `border: 2px dashed var(--border);
  color: var(--muted);
  text-align: center;
  padding: 24px;
  border-radius: 12px;
}


.kv` → styles.css
- `box-shadow 0.18s ease` → css/components/results-fun.css
- `box-sizing: border-box;
}

.toggle-label` → css/components/forms.css
- `box-sizing: border-box;
}
html` → styles.css
- `color 0.2s ease;
}


#results
  .metric:not(.band-good):not(.band-avg):not(.band-watch):not(.band-poor)` → css/components/metric-bands.css
- `color-mix(in srgb` → css/components/results-fun.css
- `color: #0fd658;
} 
#results .metric.band-avg .metric__value` → css/components/metric-bands.css
- `color: #111827;
}
.more-metrics .grid--more` → styles.css
- `color: #3b8144;
} 
#results .metric.band-watch .metric__value` → css/components/metric-bands.css
- `color: #b45309;
} 
#results .metric.band-poor .metric__value` → css/components/metric-bands.css
- `color: #dc2626;
  border-color: #dc2626;
}


.results[data-help="off"] .info` → css/components/help.css
- `color: #dc2626;
  border-color: #dc2626;
}


@media (max-width: 480px)` → css/components/help.css
- `color: #dc2626;
} 


#results .metric.band-good` → css/components/metric-bands.css
- `color: var(--muted` → css/components/results.css
- `color: var(--muted);
  font-size: 12px;
}

.expando` → styles.css
- `color: var(--muted);
}
.kv .v` → styles.css
- `color: var(--ok);
  margin-top: 8px;
}

.ad` → styles.css
- `cursor: pointer;
  padding: 8px 0;
  color: #334155;
  font-weight: 600;
}
.more-metrics[open] summary` → styles.css
- `cursor: pointer;
}

.actions` → styles.css
- `display: block;
  width: 100%;
  min-height: 50px; 
  margin: 10px 0 8px;
}
.ad.ad--mobile .ad__placeholder` → css/components/ads.css
- `display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  border: 1px solid var(--border);
  border-radius: 8px;
  background: #fff;
}

.actions` → styles.css
- `display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600; 
  margin: 4px 0;
}


.toggle-label input[type="checkbox"]` → css/components/forms.css
- `display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}
.site-header h1` → css/components/header.css
- `display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.units-switch` → css/components/units.css
- `display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: var(--card);
  border-bottom: 1px solid var(--border);
}
.site-footer` → styles.css
- `display: flex;
  flex-direction: column;
  gap: 6px;
}
label` → styles.css
- `display: flex;
  flex-wrap: wrap;
  gap: var(--alt-gap);
}

.alt-feed .row .field` → css/components/alt-feed.css
- `display: flex;
  flex-wrap: wrap;
  gap: var(--gap);
}
.feed-prices .row .field` → css/components/feed-prices.css
- `display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.seg label` → styles.css
- `display: flex;
  gap: 8px;
  margin-top: 8px;
}
.btn` → styles.css
- `display: flex;
  justify-content: space-between;
  gap: 8px;
  padding: 4px 0;
  border-bottom: 1px dotted var(--border);
}
.kv .k` → styles.css
- `display: grid;
  gap: 8px;
}
#results .kv .row` → css/components/results.css
- `display: grid;
  gap: var(--space-2);
  grid-template-columns: repeat(2` → css/components/density.css
- `display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}
@media (max-width: 720px)` → styles.css
- `display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px 12px;
}
.kv .row` → styles.css
- `display: grid;
  grid-template-columns: 1fr auto;
  gap: 6px 12px;
  align-items: baseline;
}
#results .kv .k` → css/components/results.css
- `display: grid;
  grid-template-columns: 1fr auto;
  gap: 6px 12px;
  align-items: baseline;
}
.kv .k` → styles.css
- `display: grid;
  grid-template-columns: 1fr; 
  gap: var(--space-2);
  margin-top: var(--space-2);
}
.actions .btn` → css/components/density.css
- `display: grid;
  grid-template-columns: repeat(2` → css/components/results-clean.css
- `display: grid;
  grid-template-columns: repeat(4` → styles.css
- `display: grid;
  grid-template-columns: repeat(auto-fit` → css/components/forms.css
- `display: inline-block;
  margin-left: 8px;
  padding: 2px 8px;
  border-radius: 9999px;
  font-size: 11px;
  font-weight: 700;
  background: #fff7ed; 
  color: #b45309; 
  border: 1px solid #fdba74; 
  vertical-align: middle;
}

@media (max-width: 360px)` → css/components/header.css
- `display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  margin-left: 6px;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  line-height: 1;
  border-radius: 9999px;
  border: 1px solid currentColor;
  background: transparent;
  color: #64748b; 
}


.info--alert` → css/components/help.css
- `display: inline-flex;
  padding: 2px;
  border: 1px solid #cbd5e1;
  border-radius: 9999px;
  background: #fff;
}
.units-switch .seg` → css/components/units.css
- `display: none !important;
  }
}
.seg` → styles.css
- `display: none;
  } 
}
.site-header` → css/components/header.css
- `display: none;
}


#helpPopover` → css/components/help.css
- `display: none;
}


.metric[data-help="off"] .info` → css/components/help.css
- `display: none;
}


@media (max-width: 420px)` → css/components/results-clean.css
- `display: none;
}

.more-metrics summary` → styles.css
- `display: none;
}
#helpPopover h4` → css/components/help.css
- `display: none;
}
.btn.linklike.small` → css/components/results-clean.css
- `flex-direction: column;
  }
  .post-actions .btn.block` → css/components/results.css, styles.css
- `flex-wrap: wrap;
  }
}


.kv .row` → styles.css
- `flex: 1 1 100%;
    min-width: 0;
  }
}

.feed-prices .alt-feed` → css/components/feed-prices.css
- `flex: 1 1 var(--alt-min);
  min-width: var(--alt-min);
}

.alt-feed input[type="number"]` → css/components/alt-feed.css
- `flex: 1 1 var(--min);
  min-width: var(--min);
}
.feed-prices input[type="number"]` → css/components/feed-prices.css
- `font-size: 1.05rem;
}




.actions` → css/components/density.css
- `font-size: 1.25rem;
}
h3` → css/components/density.css
- `font-size: 1.6rem;
} 
h2` → css/components/density.css
- `font-size: 12px;
  color: var(--muted);
}

.session-note` → styles.css
- `font-size: var(--font-base);
}


label` → css/components/density.css
- `font-size: var(--font-label);
}


input[type="text"]` → css/components/density.css
- `font-size: var(--font-metric);
}


h1` → css/components/density.css
- `font-weight: 600;
}


@media (max-width: 600px)` → css/components/results.css, styles.css
- `font-weight: 600;
}


@media print` → styles.css
- `font-weight: 600;
}
input` → styles.css
- `font-weight: 700;
  font-size: 18px;
  color: var(--brand);
}
.metric__label` → styles.css
- `font-weight: 800;
  letter-spacing: 0.2px;
  color: var(--band-color` → css/components/results-clean.css
- `font-weight: 800;
  letter-spacing: 0.2px;
}
#metricsGrid.metric-grid-scope .metric .metric__label` → css/components/results-fun.css
- `font-weight: 800;
  letter-spacing: 0.2px;
}
.fun-grid .metric__label` → css/components/results-fun.css
- `gap: 10px;
  }
}


#metricsGrid .metric.band-excellent` → css/components/results-clean.css
- `gap: 8px;
  }
  #results .kv .row` → styles.css
- `gap: var(--space-3);
  margin-bottom: var(--space-3);
}
.grid` → css/components/density.css
- `gap: var(--space-3);
}


.metric` → css/components/density.css
- `grid-template-columns: 1fr 1fr; 
  gap: 10px;
}
.row.row--compact .field input` → css/components/forms.css
- `grid-template-columns: 1fr;
  }
  #results .kv .v` → css/components/results.css, styles.css
- `grid-template-columns: 1fr;
  }
}


.card-title` → css/components/density.css
- `grid-template-columns: 1fr;
  }
}

.field` → styles.css
- `grid-template-columns: 1fr;
  } 
  .post-actions` → css/components/density.css
- `grid-template-columns: repeat(2` → styles.css
- `height: 50px;
  border: 1px dashed #cbd5e1;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  color: #64748b;
  background: #f8fafc;
}


@media (min-width: 768px)` → css/components/ads.css
- `input[type="email"]` → css/components/density.css
- `input[type="number"]` → css/components/density.css
- `input[type="search"]` → css/components/density.css
- `input[type="tel"]` → css/components/density.css
- `input[type="url"]` → css/components/density.css
- `justify-self: start;
  }
}


.post-actions` → css/components/results.css
- `justify-self: start;
  }
}

.post-actions` → styles.css
- `margin-bottom: var(--space-3);
}

.grid > .metric[hidden]` → css/components/density.css
- `margin-bottom: var(--space-3);
}
.issues` → css/components/density.css
- `margin-left: 12px;
  font-size: 14px;
}
.unit-toggle input` → styles.css
- `margin-left: 24px;
  display: block; 
  margin-top: 2px;
}

.row.row--compact` → css/components/forms.css
- `margin-right: 6px;
}

.card` → styles.css
- `margin-top: 12px;
  display: flex;
  gap: 10px;
  justify-content: flex-start;
}
.post-actions .btn` → styles.css
- `margin-top: 12px;
  display: flex;
  gap: 10px;
}
.post-actions .btn` → css/components/results.css
- `margin-top: 12px;
}
.feed-prices .alt-feed .alt-box` → css/components/feed-prices.css
- `margin-top: 12px;
}
.grid` → styles.css
- `margin-top: 4px;
  color: #475569;
  font-size: 12px;
  line-height: 1.2;
  position: static;
  padding-right: 0;
}
#moreMetrics .metric .info` → css/components/results-clean.css
- `margin-top: 4px;
  color: #475569; 
  font-size: 12px;
  line-height: 1.2;
  padding-right: 26px; 
  position: relative;
}


#metricsGrid .metric .info` → css/components/results-clean.css
- `margin-top: 8px;
  padding: 10px;
  border-radius: 8px;
  background: #fff3f1;
  border: 1px solid #ffd6cf;
  color: #7a2314;
}

.results` → styles.css
- `margin-top: var(--space-2);
}
.printable` → css/components/density.css
- `margin: 0 0 6px 0;
  font-size: 13px;
  color: #111827;
}
#helpPopover p` → css/components/help.css
- `margin: 0 0 8px;
}

.row` → styles.css
- `margin: 0;
  font-size: 12px;
  line-height: 1.2;
}
@media (max-width: 480px)` → css/components/header.css
- `margin: 0;
  font-size: 13px;
  color: #374151;
}

#results .metric` → css/components/help.css
- `margin: 0;
  line-height: 1.2;
}
.slogan` → css/components/header.css
- `margin: 0;
  padding: 0;
  font-family: system-ui` → styles.css
- `margin: 4px 0 0;
  color: #334155; 
}

.badge` → css/components/header.css
- `margin: 4px 0 10px;
  color: #334155;
  font-size: 13px;
}
#metricsGrid` → css/components/results-fun.css
- `margin: 6px 0 8px;
}
.expando summary` → styles.css
- `max-width: 980px;
  margin: 0 auto;
  padding: 16px;
}

.site-header` → styles.css
- `min-width: 0;
}


.card` → css/components/forms.css
- `min-width: 0;
}
.field input` → css/components/forms.css
- `min-width: 160px;
}


@media (max-width: 720px)` → styles.css
- `min-width: 160px;
}
@media (max-width: 720px)` → css/components/results.css
- `minmax(0` → css/components/results-clean.css
- `minmax(220px` → css/components/forms.css
- `opacity: 0.9;
}


@media (hover: hover)` → css/components/results-fun.css
- `outline: 2px dashed hotpink;
}



#metricsGrid.metric-grid-scope .metric` → css/components/results-fun.css
- `outline: 2px solid #cde8cd;
  border-color: #cde8cd;
}

.hint` → styles.css
- `overflow: hidden;
}


*` → css/components/forms.css
- `padding-right: 42px;
  }
  #results .metric .info` → css/components/help.css
- `padding: 10px 12px;
  border: 1px solid var(--border);
  border-radius: 8px;
  font-size: 16px;
  background: #fff;
}
input:focus` → styles.css
- `padding: 6px 0;
}
.site-header .container` → css/components/header.css
- `padding: 8px 10px;
  min-height: 44px;
}


.row` → css/components/density.css
- `padding: var(--space-2) var(--space-3);
}
.metric__value` → css/components/density.css
- `position: absolute;
    left: 0;
    top: 0;
    width: 100%;
  }
  .site-header` → styles.css
- `position: absolute;
  inset: 0;
  opacity: 0;
  cursor: pointer;
}
.units-switch .seg span` → css/components/units.css
- `position: absolute;
  left: -10000px;
  width: 1px;
  height: 1px;
  overflow: hidden;
}

.grid > .metric[hidden]` → styles.css
- `position: absolute;
  top: 6px;
  right: 6px;
  width: 18px;
  height: 18px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 9999px;
  border: 1px solid currentColor;
  background: #fff;
  color: #64748b; 
}


#metricsGrid > .metric[hidden]` → css/components/results-clean.css
- `position: absolute;
  top: 6px;
  right: 6px;
  z-index: 1;
  width: 18px;
  height: 18px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 9999px;
  border: 1px solid currentColor;
  background: #fff;
  color: #64748b;
}
#moreMetrics > .metric[hidden]` → css/components/results-clean.css
- `position: absolute;
  top: 6px;
  right: 6px;
  z-index: 1;
}

#moreMetrics.grid` → css/components/results-clean.css
- `position: absolute;
  top: 8px;
  right: 8px;
  margin-left: 0; 
  width: 18px;
  height: 18px; 
  z-index: 2;
  background: #fff; 
  border: 1px solid currentColor;
  border-radius: 9999px;
}


#results .metric .info.info--alert` → css/components/help.css
- `position: absolute;
  z-index: 1000;
  max-width: 280px;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 10px 12px;
  box-shadow: 0 8px 28px rgba(0` → css/components/help.css
- `position: relative;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-left: 8px solid var(--band-color` → css/components/results-clean.css
- `position: relative;
  background: #fff;
  border: 1px solid #e5e7eb; 
  border-left: 8px solid var(--band-color` → css/components/results-clean.css
- `position: relative;
  background: var(--tile-bg` → css/components/results-fun.css
- `position: relative;
  background: var(--tile-bg);
  border: 1px solid var(--tile-border);
  border-left: 6px solid var(--band-color` → css/components/results-fun.css
- `position: relative;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 1;
  padding: 6px 10px;
  cursor: pointer;
}
.units-switch .seg input` → css/components/units.css
- `position: relative;
  padding-right: 36px;
} 

#results .metric .info` → css/components/help.css
- `position: relative;
  z-index: 1;
}
.units-switch .seg input:checked + span` → css/components/units.css
- `position: relative;
} 
#metricsGrid .metric .metric__label` → css/components/results-clean.css
- `position: static;
  padding-right: 0;
}
#metricsGrid .metric .info` → css/components/results-clean.css
- `sans-serif;
  color: var(--ink);
  background: var(--bg);
}

.wrap` → styles.css
- `select` → css/components/density.css
- `small` → css/components/density.css
- `textarea` → css/components/density.css, styles.css
- `textarea:focus` → styles.css
- `transform: none;
    transition: none;
  }
}


#metricsGrid.metric-grid-scope .metric.band-excellent` → css/components/results-fun.css
- `transform: none;
    transition: none;
  }
}


.fun-grid .metric.band-excellent` → css/components/results-fun.css
- `transform: rotate(0deg) scale(1.015);
    box-shadow: 0 2px 0 rgba(0` → css/components/results-fun.css
- `transform: translateY(1px);
}

.issues` → styles.css
- `var(--band-color` → css/components/results-fun.css
- `visibility: hidden !important;
  }
  #results` → styles.css
- `visibility: visible !important;
  }
  #results` → styles.css
- `width: 100%;
  justify-content: center;
}

.actions .btn` → css/components/density.css
- `width: 100%;
  max-width: 100%;
  box-sizing: border-box;
  margin-top: 8px;
}

.alt-feed .row` → css/components/alt-feed.css
- `width: 100%;
  max-width: 100%;
  box-sizing: border-box;
  margin-top: 8px;
}
.feed-prices .row` → css/components/feed-prices.css
- `width: 100%;
  max-width: 100%;
  box-sizing: border-box;
}


.card` → css/components/forms.css
- `width: 100%;
  max-width: 700px;
  margin: 0 auto;
  padding: 12px 16px;
  box-sizing: border-box;
}


.site-header` → css/components/layout.css
- `width: 100%;
  }
}
.visually-hidden` → styles.css
- `width: 100%;
}


@media (max-width: 640px)` → css/components/alt-feed.css
- `width: 100%;
}


@media (max-width: 768px)` → css/components/density.css
- `width: 100%;
}
@media (max-width: 360px)` → css/components/forms.css
- `width: 100%;
}
@media (max-width: 640px)` → css/components/feed-prices.css
- `width: 100%;
} 


.post-actions` → css/components/density.css
- `width: 16px;
  height: 16px;
  min-width: 16px;
  min-height: 16px;
  accent-color: #16a34a; 
}


.toggle-label + .unit-note` → css/components/forms.css