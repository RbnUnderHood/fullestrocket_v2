# RELEASE_NOTES.md — FCR Web Calculator (USA)

Release date: 2025-09-15  
Version tag: v0.3.2

1) Summary
Cleanup-only release to align code with the new workflow: centralized spacing tokens in `theme.css`, consolidated `.post-actions` ownership in `density.css`, added core docs, and a packaging script. No intentional visual changes.

2) Changes
- Features:
  - PowerShell packaging script `scripts/make_zip.ps1` to create clean ZIPs and print the send template.
- Fixes:
  - None.
- Chores/Docs:
  - Added `docs/THEME_TOKENS.md`, `docs/SELECTOR_MAP.md`, `docs/CLEANUP_REPORT.md`, `docs/SEND_TEMPLATE.md`.
  - Updated project docs to reflect ownership and handoff process.
- Refactors (no visual change):
  - Centralized `--space-{1..4}` in `css/theme.css` and removed duplicates from `css/components/density.css`.
  - Moved `.post-actions` rules to the owner (`css/components/density.css`) and removed duplicates from `css/components/results.css`.

3) Files touched (owner map)
- css/theme.css — tokens in `:root` (owns spacing tokens now).
- css/components/density.css — owns `.actions` and `.post-actions`; references centralized spacing tokens.
- css/components/results.css — removed duplicate `.post-actions` rules (owner is density.css).
- docs/THEME_TOKENS.md — token source of truth and “Try Me (SAFE)”.
- docs/SELECTOR_MAP.md — selector ownership guide.
- docs/CLEANUP_REPORT.md — duplicates and next steps.
- docs/SEND_TEMPLATE.md — message template for ZIP handoffs.
- scripts/make_zip.ps1 — clean ZIP generator.

4) Visual changes
- [x] None (cleanup only)
- [ ] Yes (describe): n/a

5) Tests performed (smoke)
- [ ] No console errors in Chrome/Firefox/Safari.
- [ ] Mobile 360–414px: inputs readable; buttons ≥44px; tiles wrap.
- [ ] Help (i) opens/closes; ESC & click-away work.
- [ ] Export/Print row behaves; no layout shift.
- [ ] Keyboard focus visible; tab order sensible.
Notes: Manual verification pending; expected no change.

6) Known issues / TODO
- Decide on default tile system (suggest `css/components/results-clean.css` for production) and archive alternates.
- Finalize brand palette tokens; align tile band colors with chosen palette.

7) Rollback plan
- Revert to previous ZIP or tag. Confirm no console errors.

8) Artifacts
- Built CSS bundle: `dist/app.css` — [ ] yes  [x] no
- Project ZIP: `releases/fcr-web-calculator-20250915-0902-clean.zip`

9) Handoff → Codex (in VS Code)
- Change request: Move `--font-*` tokens to `css/theme.css` (no visual change).
  - Files to touch: `css/theme.css`, `css/components/density.css`.
  - Constraints: tokens only; no component overrides.
  - Acceptance: app renders identically; DevTools shows font tokens only in `:root`.
  - Test notes: refresh; compare headings/labels/metric values.

10) Handoff → ChatGPT (project chat)
- Decisions needed:
  - Final palette (Farm Fresh vs Field Green) and token values.
  - Export formats (CSV only vs CSV+JSON+pretty text).
  - Whether to ship a desktop sidebar ad container in MVP.

