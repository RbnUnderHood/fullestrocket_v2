Cleanup Report (Current State)

Goal: keep styles conflict‑free by enforcing one‑owner per selector and centralizing tokens.

Findings
- Duplicate selector: `.post-actions`
  - Found in `css/components/results.css` and `css/components/density.css`.
  - Recommendation: keep ownership in `css/components/density.css`. Remove/avoid the version in `results.css` to prevent competing layout rules.

- Tile styling spread across multiple variants
  - Files: `results-clean.css`, `metric-bands.css`, and `results-fun.css` (takeover under `#metricsGrid.metric-grid-scope`).
  - Recommendation: choose one default tile system for production (suggest `results-clean.css`).
    - If experimenting, keep alternates behind a class toggle or move to `css/_archive/`.

- Info button pinning defined in two places
  - Files: `help.css` (generic `#results .metric .info`) and `results-clean.css` (`#metricsGrid .metric .info`).
  - Recommendation: let `help.css` own `.info` behavior globally; keep any grid‑specific adjustments minimal in the grid’s file.

- Spacing and type scale tokens live in a component
  - File: `css/components/density.css` defines `--space-*` and `--font-*`.
  - Recommendation: move these to `css/theme.css` so all components share them consistently.

Beginner‑friendly steps (spacing tokens move)
1) Open `css/theme.css`, inside `:root {}` add:
   - `--space-1: 6px;`
   - `--space-2: 10px;`
   - `--space-3: 12px;`
   - `--space-4: 16px;`
2) In `css/components/density.css`, delete the same `--space-*` lines inside its `:root {}` block (leave usages like `var(--space-3)` alone).
3) Refresh the browser. Everything should look the same.
4) If spacing changed, undo and we’ll adjust together.

Verification checklist
- Open DevTools → Console: no CSS errors.
- Resize to 360–768–1024px: `.actions` and `.post-actions` layout stays consistent.
- Toggle any “fun grid” class if used: tiles shouldn’t double‑style.

Notes
- Some docs show stray replacement characters (�). Save docs as UTF‑8 to clear them.
- Archive candidates: `css/components/metric-bands.css`, `css/components/results-fun.css` if not used in the current design.

