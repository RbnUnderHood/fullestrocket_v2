# CONTRIBUTING.md — FCR Web Calculator (USA)

Welcome! This guide keeps code clean and changes safe. If you’re using **Codex** in VS Code, follow the rules below. For broader design/architecture, coordinate in ChatGPT.

---

## 1) Roles & workflow

- **Codex (in-editor):** small/medium code edits; implement tickets that touch 1–2 files; quick refactors; bug fixes.
- **ChatGPT (this project chat):** goals/scope, IA/UX, design tokens, large refactors, release notes, docs, plans.
- **Protocol:** If a change spans multiple areas or alters tokens/UX, propose it here first. For simple code edits, proceed in Codex and stick to the owner file(s).

---

## 2) Repo structure (owner files)

```
index.html
styles.css                # reset + page shell only
/css
  theme.css               # all tokens (colors/spacing/type/radii/shadows)
  /components
    layout.css            # container widths/padding
    header.css            # site header, slogan, badge
    forms.css             # inputs, .row/.field grids
    density.css           # compact scale + .actions / .post-actions
    units.css             # units switch control
    help.css              # info button + popover
    feed-prices.css       # subform
    alt-feed.css          # nested form variant
    results.css           # KV summary helpers (no tiles)
    results-clean.css     # ✅ tiles grid + tile internals
    ads.css               # ad placeholders
/js
  compute.js              # pure calc & conversions
  performance.js          # timing/perf helpers
  ui.js                   # event handlers, DOM updates
/dist
  app.css                 # built bundle (optional for prod)
```

**One selector = one owner file.** See `SELECTOR_MAP.md` for the latest truth.

---

## 3) Run & build

- **Dev:** open `index.html` or run `py -m http.server 5500` and visit `http://localhost:5500/`.
- **Build CSS:** run `build_css.bat` (Windows) to create/refresh `dist/app.css`.
- **Auto-switch (optional):** an inline snippet in `<head>` loads multi-file locally and `dist/app.css` when hosted. Do not modify unless requested.

---

## 4) CSS rules of the road

- **Tokens live only in `css/theme.css`.** Components reference them; they don’t define new tokens.
- **Ownership:**  
  - Tiles → `css/components/results-clean.css`  
  - KV Summary → `css/components/results.css`  
  - Actions/Export & compact scale → `css/components/density.css`  
  - Forms & grids → `css/components/forms.css`  
  - Help popover/ⓘ → `css/components/help.css`
- **Naming:** BEM-ish: `.component__element--modifier` + light state classes `.is-open`, `.is-disabled`.
- **Specificity:** prefer classes; avoid IDs; use `:where()` to scope without increasing specificity.
- **Headers at top of every CSS file (paste this):**
  ```css
  /* ==========================================================================
     FILE: components/results-clean.css
     ROLE: KPI tiles grid + tile internals
     OWNS: #metricsGrid, #moreMetrics, .metric, .metric__value, .metric__label
     NO-GO: Do not style forms or header/footer here
     ========================================================================== */
  ```
- **Section dividers inside files:**
  ```css
  /* == Layout & grid ======================================================== */
  /* == Component body ======================================================= */
  /* == States & modifiers =================================================== */
  /* == Responsive tweaks ==================================================== */
  ```
- **Utilities (optional):** if you add `utilities.css`, keep it tiny (e.g., `.u-flex`, `.u-gap-2`, `.is-hidden`) and include it before component files in dev and before `results.css` in `build_css.bat`.

**Do not change visuals** unless the ticket explicitly allows it. Cleanups should move/annotate code only.

---

## 5) HTML & JS style

- **HTML:** semantic tags; no inline styles; ARIA labels for interactive icons; keep the DOM simple.
- **JS:**  
  - Pure math in `compute.js` (no DOM).  
  - UI wiring in `ui.js` (event listeners, rendering).  
  - Keep functions short; prefer clear names to comments; no frameworks/build tools.

---

## 6) Commit messages & branches

- **Commit format:** `feat|fix|chore: short summary (#section)`
  - Examples:  
    - `fix: scope .post-actions to results only (#css)`  
    - `chore: add headers to forms.css (#docs)`
- **Branch (optional):** `type/short-topic` (e.g., `fix/post-actions-mobile`).

---

## 7) Change request template (open a small ticket)

**Change request:** one-sentence goal.  
**Files to touch:** explicit list (1–2 files preferred).  
**Constraints:** e.g., “No visual change”, “Tiles only”, “Tokens only”.  
**Acceptance criteria:** bullet list of what must be true.  
**Test notes:** how to verify quickly (selectors, viewport sizes).

_Example:_  
- Change request: “Stack post-actions on phones using existing density system.”  
- Files: `css/components/density.css` only.  
- Constraints: no tokens/HTML changes.  
- Acceptance: 2-up ≥768px; stacked <768px; buttons 100% width when stacked.  
- Test: check at 375px and 1024px; click buttons; no layout shift.

---

## 8) Review checklist (PR or local self-check)

- No console errors/warnings.
- File ownership respected (no duplicate selectors across files).
- Tokens referenced, not redefined, outside `theme.css`.
- Mobile: tap targets ≥44px; forms/toggles readable; tiles wrap cleanly.
- Help popover works; not obscured by z-index issues.
- Export/Print row aligns; buttons full-width on small screens.
- If it’s a cleanup: **visual diff unchanged**.

---

## 9) Accessibility & UX minimums

- Color contrast AA for text on default surfaces.  
- Keyboard focus visible; interactive elements reachable.  
- Hit targets ~44×44px minimum on touch devices.  
- Avoid motion that can’t be reduced (respect `prefers-reduced-motion`).

---

## 10) Releasing

- Run `build_css.bat` → confirm `dist/app.css` exists.
- Sanity test on mobile & desktop.
- Package a ZIP with the full project.
- Include a short `RELEASE_NOTES.md` (changes + test checklist results).

---

## 11) Common pitfalls

- Editing tokens in component files (don’t) → put them in `theme.css`.
- Duplicating `.post-actions` in multiple files → **owner is `density.css`**.
- Styling tiles from anywhere except `results-clean.css`.
- Cleanups that change values (they must not).

---

## 12) Need help?

- Big questions, UX decisions, or refactors → open a discussion in ChatGPT.
- Small, isolated code edits → do them with Codex in VS Code, following the owner map.
