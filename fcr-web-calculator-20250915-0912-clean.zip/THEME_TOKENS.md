# Theme Tokens (Documentation Only)
These reflect current variables from `css/theme.css` and any component-local variables.

## Global `:root` tokens (css/theme.css)
- `--rooster-red`: `#c41e3a`
- `--hen-brown`: `#8b4513`
- `--chick-yellow`: `#ffd700`
- `--feather-black`: `#2f1b14`
- `--egg-cream`: `#f5f5dc`
- `--copper-orange`: `#cd7f32`
- `--barn-red`: `#b22222`
- `--weathered-wood`: `#8b7355`
- `--hay-gold`: `#daa520`
- `--field-green`: `#556b2f`
- `--sky-blue`: `#87ceeb`
- `--milk-white`: `#fffdd0`
- `--earth-brown`: `#964b00`
- `--sunset-orange`: `#ff8c69`
- `--corn-yellow`: `#ffde00`
- `--tile-bg`: `#ffffff`
- `--tile-border`: `#e5e7eb`
- `--tile-shadow`: `0 1px 0 rgba(0, 0, 0, 0.06), 0 6px 16px rgba(15, 23, 42, 0.06)`

## Component-local variables (documented)
- **alt-feed.css**
  - `--alt-gap`: `12px`
  - `--alt-min`: `240px`
- **density.css**
  - `--font-base`: `14px`
  - `--font-label`: `13px`
  - `--font-metric`: `18px`
  - `--space-1`: `6px`
  - `--space-2`: `10px`
  - `--space-3`: `12px`
  - `--space-4`: `16px`
- **feed-prices.css**
  - `--gap`: `12px`
  - `--min`: `240px`
- **metric-bands.css**
  - `--tile-bg`: `#ffffff`
  - `--tile-border`: `#e5e7eb`
- **results-clean.css**
  - `--band-color`: `#c41e3a`
- **results-fun.css**
  - `--band-color`: `var(--rooster-red, #c41e3a)`

## Proposed accessible palettes (WCAG AA for text on white)
- **Farm Fresh**: brand `#2563EB`, success `#16A34A`, warning `#B45309`, danger `#DC2626`, text `#111827`.
- **Field Green**: brand `#2E7D32`, success `#22C55E`, warning `#D97706`, danger `#DC2626`, text `#1F2937`.

## TRY-ME (SAFE)
```css
/* Paste into css/theme.css to re-skin, values mirror today */
:root {
  --rooster-red: #c41e3a;
  --hen-brown: #8b4513;
  --chick-yellow: #ffd700;
  --feather-black: #2f1b14;
  --egg-cream: #f5f5dc;
  --copper-orange: #cd7f32;
  --barn-red: #b22222;
  --weathered-wood: #8b7355;
  --hay-gold: #daa520;
  --field-green: #556b2f;
  --sky-blue: #87ceeb;
  --milk-white: #fffdd0;
  --earth-brown: #964b00;
  --sunset-orange: #ff8c69;
  --corn-yellow: #ffde00;
  --tile-bg: #ffffff;
  --tile-border: #e5e7eb;
  --tile-shadow: 0 1px 0 rgba(0, 0, 0, 0.06), 0 6px 16px rgba(15, 23, 42, 0.06);
}
```